"""
معالجات أوامر تليجرام لبوت إدارة الميكروتك
"""

import logging
from typing import Dict, Any
from datetime import datetime
import re

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

from config import MESSAGES, TEMPLATES, ALLOWED_USERS
from database import DatabaseManager
from mikrotik_api_client import MikroTikAPIClient
from models import MikroTikDevice

logger = logging.getLogger(__name__)

class TelegramHandlers:
    """معالجات أوامر تليجرام"""
    
    def __init__(self, db_manager: DatabaseManager):
        self.db = db_manager
        self.active_connections: Dict[int, MikroTikAPIClient] = {}
    
    def is_user_authorized(self, user_id: int) -> bool:
        """فحص تفويض المستخدم"""
        if ALLOWED_USERS and user_id not in ALLOWED_USERS:
            return False
        return self.db.is_user_authorized(user_id) or not ALLOWED_USERS
    
    def get_user_connection(self, user_id: int) -> MikroTikAPIClient:
        """الحصول على اتصال المستخدم بالميكروتك"""
        return self.active_connections.get(user_id)
    
    def create_main_keyboard(self) -> InlineKeyboardMarkup:
        """إنشاء لوحة المفاتيح الرئيسية"""
        keyboard = [
            [
                InlineKeyboardButton("📊 معلومات النظام", callback_data="system_info"),
                InlineKeyboardButton("🔥 الهوتسبوت", callback_data="hotspot_menu")
            ],
            [
                InlineKeyboardButton("🎫 كروت الهوتسبوت", callback_data="hotspot_cards"),
                InlineKeyboardButton("🔍 تشخيص المشاكل", callback_data="troubleshoot")
            ],
            [
                InlineKeyboardButton("🌐 اكتشاف الأجهزة", callback_data="discover_devices"),
                InlineKeyboardButton("🔄 إعادة التشغيل", callback_data="reboot_confirm")
            ],
            [
                InlineKeyboardButton("⚙️ الإعدادات", callback_data="settings"),
                InlineKeyboardButton("📋 السجل", callback_data="operation_logs")
            ]
        ]
        return InlineKeyboardMarkup(keyboard)
    
    def create_hotspot_keyboard(self) -> InlineKeyboardMarkup:
        """إنشاء لوحة مفاتيح الهوتسبوت"""
        keyboard = [
            [
                InlineKeyboardButton("👥 المستخدمون النشطون", callback_data="hotspot_active"),
                InlineKeyboardButton("📋 جميع المستخدمين", callback_data="hotspot_all")
            ],
            [
                InlineKeyboardButton("➕ إضافة مستخدم", callback_data="hotspot_add"),
                InlineKeyboardButton("🔍 البحث عن مستخدم", callback_data="hotspot_search")
            ],
            [
                InlineKeyboardButton("🔙 العودة للقائمة الرئيسية", callback_data="main_menu")
            ]
        ]
        return InlineKeyboardMarkup(keyboard)
    
    async def start_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """معالج أمر /start"""
        user = update.effective_user
        user_id = user.id
        
        # إضافة المستخدم إلى قاعدة البيانات
        self.db.add_user(user_id, user.username, user.first_name, user.last_name)
        
        if not self.is_user_authorized(user_id):
            await update.message.reply_text(MESSAGES['unauthorized'])
            return
        
        # تفويض المستخدم تلقائياً إذا لم تكن هناك قيود
        if not ALLOWED_USERS:
            self.db.authorize_user(user_id)
        
        await update.message.reply_text(
            MESSAGES['welcome'],
            reply_markup=self.create_main_keyboard()
        )
        
        self.db.log_operation(user_id, "start", "بدء استخدام البوت", True)
    
    async def login_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """معالج أمر /login"""
        user_id = update.effective_user.id
        
        if not self.is_user_authorized(user_id):
            await update.message.reply_text(MESSAGES['unauthorized'])
            return
        
        await update.message.reply_text(MESSAGES['login_prompt'])
        
        # تعيين حالة انتظار بيانات تسجيل الدخول
        context.user_data['waiting_for_login'] = True
    
    async def handle_login_data(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """معالجة بيانات تسجيل الدخول"""
        user_id = update.effective_user.id
        text = update.message.text.strip()
        
        # تحليل بيانات الاتصال
        parts = text.split(':')
        if len(parts) < 4:
            await update.message.reply_text(
                "❌ تنسيق خاطئ. يرجى استخدام التنسيق:\nIP:PORT:USERNAME:PASSWORD"
            )
            return
        
        ip = parts[0]
        try:
            port = int(parts[1])
        except ValueError:
            await update.message.reply_text("❌ المنفذ يجب أن يكون رقماً")
            return
        
        username = parts[2]
        password = parts[3]
        use_ssl = len(parts) > 4 and parts[4].lower() == 'ssl'
        
        # إنشاء جهاز الميكروتك
        device = MikroTikDevice(ip, port, username, password, use_ssl)
        
        # محاولة الاتصال
        processing_msg = await update.message.reply_text(MESSAGES['processing'])
        
        client = MikroTikAPIClient(device)
        if client.connect():
            # حفظ الجهاز في قاعدة البيانات
            device_id = self.db.add_mikrotik_device(user_id, device)
            
            if device_id:
                # إنشاء جلسة المستخدم
                self.db.create_user_session(user_id, device_id)
                
                # حفظ الاتصال النشط
                self.active_connections[user_id] = client
                
                await processing_msg.edit_text(
                    MESSAGES['login_success'],
                    reply_markup=self.create_main_keyboard()
                )
                
                self.db.log_operation(user_id, "login", f"تسجيل دخول ناجح إلى {device}", True)
            else:
                client.disconnect()
                await processing_msg.edit_text("❌ خطأ في حفظ بيانات الجهاز")
        else:
            await processing_msg.edit_text(MESSAGES['login_failed'])
            self.db.log_operation(user_id, "login", f"فشل تسجيل الدخول إلى {device}", False)
        
        # إزالة حالة انتظار تسجيل الدخول
        context.user_data.pop('waiting_for_login', None)
    
    async def handle_callback_query(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """معالج الاستعلامات المرجعية (Callback Queries)"""
        query = update.callback_query
        user_id = query.from_user.id
        data = query.data
        
        if not self.is_user_authorized(user_id):
            await query.answer(MESSAGES['unauthorized'])
            return
        
        # تحديث نشاط المستخدم
        self.db.update_user_activity(user_id)
        
        await query.answer()
        
        # توجيه الاستعلام حسب النوع
        if data == "main_menu":
            await self.show_main_menu(query)
        elif data == "system_info":
            await self.show_system_info(query)
        elif data == "hotspot_menu":
            await self.show_hotspot_menu(query)
        elif data == "hotspot_active":
            await self.show_hotspot_active_users(query)
        elif data == "hotspot_all":
            await self.show_hotspot_all_users(query)
        elif data == "hotspot_cards":
            await self.show_hotspot_cards_menu(query)
        elif data == "troubleshoot":
            await self.show_troubleshoot_menu(query)
        elif data == "discover_devices":
            await self.discover_devices(query)
        elif data == "reboot_confirm":
            await self.show_reboot_confirmation(query)
        elif data == "reboot_execute":
            await self.execute_reboot(query)
        elif data == "settings":
            await self.show_settings(query)
        elif data == "operation_logs":
            await self.show_operation_logs(query)
        else:
            await query.edit_message_text("❌ أمر غير معروف")
    
    async def show_main_menu(self, query):
        """عرض القائمة الرئيسية"""
        await query.edit_message_text(
            "🏠 القائمة الرئيسية\n\nاختر الخدمة المطلوبة:",
            reply_markup=self.create_main_keyboard()
        )
    
    async def show_system_info(self, query):
        """عرض معلومات النظام"""
        user_id = query.from_user.id
        client = self.get_user_connection(user_id)
        
        if not client or not client.is_connected():
            await query.edit_message_text(MESSAGES['not_logged_in'])
            return
        
        system_info = client.get_system_info()
        if not system_info:
            await query.edit_message_text("❌ فشل في الحصول على معلومات النظام")
            return
        
        # الحصول على معلومات الشبكة
        interfaces = client.get_interfaces()
        total_rx = sum(iface.rx_mb for iface in interfaces if iface.running)
        total_tx = sum(iface.tx_mb for iface in interfaces if iface.running)
        
        # تنسيق الرسالة
        message = TEMPLATES['system_info'].format(
            cpu_load=system_info.cpu_load,
            voltage=system_info.voltage,
            temperature=system_info.temperature,
            uptime=system_info.uptime,
            memory_usage=system_info.memory_usage_percent,
            download_speed=f"{total_rx:.1f}",
            upload_speed=f"{total_tx:.1f}",
            board_name=system_info.board_name,
            version=system_info.version,
            network_time=datetime.now().strftime("%H:%M:%S %d-%m-%Y")
        )
        
        keyboard = [[InlineKeyboardButton("🔄 تحديث", callback_data="system_info"),
                    InlineKeyboardButton("🔙 العودة", callback_data="main_menu")]]
        
        await query.edit_message_text(
            message,
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
        
        self.db.log_operation(user_id, "system_info", "عرض معلومات النظام", True)
    
    async def show_hotspot_menu(self, query):
        """عرض قائمة الهوتسبوت"""
        await query.edit_message_text(
            "🔥 إدارة الهوتسبوت\n\nاختر العملية المطلوبة:",
            reply_markup=self.create_hotspot_keyboard()
        )
    
    async def show_hotspot_active_users(self, query):
        """عرض المستخدمين النشطين في الهوتسبوت"""
        user_id = query.from_user.id
        client = self.get_user_connection(user_id)
        
        if not client or not client.is_connected():
            await query.edit_message_text(MESSAGES['not_logged_in'])
            return
        
        active_users = client.get_hotspot_active_users()
        
        if not active_users:
            message = "👥 المستخدمون النشطون\n\n❌ لا يوجد مستخدمون نشطون حالياً"
        else:
            message = f"👥 المستخدمون النشطون ({len(active_users)})\n\n"
            
            for i, user in enumerate(active_users[:10], 1):  # عرض أول 10 مستخدمين
                total_mb = (user.bytes_in + user.bytes_out) / (1024 * 1024) if user.bytes_in and user.bytes_out else 0
                message += f"{i}. 👤 {user.name}\n"
                message += f"   📍 IP: {user.ip_address}\n"
                message += f"   ⏰ الوقت: {user.uptime}\n"
                message += f"   📊 البيانات: {total_mb:.1f} MB\n\n"
            
            if len(active_users) > 10:
                message += f"... و {len(active_users) - 10} مستخدمين آخرين"
        
        keyboard = [[InlineKeyboardButton("🔄 تحديث", callback_data="hotspot_active"),
                    InlineKeyboardButton("🔙 العودة", callback_data="hotspot_menu")]]
        
        await query.edit_message_text(
            message,
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
        
        self.db.log_operation(user_id, "hotspot_active", f"عرض {len(active_users)} مستخدم نشط", True)
    
    async def show_hotspot_all_users(self, query):
        """عرض جميع مستخدمي الهوتسبوت"""
        user_id = query.from_user.id
        client = self.get_user_connection(user_id)
        
        if not client or not client.is_connected():
            await query.edit_message_text(MESSAGES['not_logged_in'])
            return
        
        all_users = client.get_hotspot_users()
        
        if not all_users:
            message = "📋 جميع مستخدمي الهوتسبوت\n\n❌ لا يوجد مستخدمون مسجلون"
        else:
            message = f"📋 جميع مستخدمي الهوتسبوت ({len(all_users)})\n\n"
            
            for i, user in enumerate(all_users[:15], 1):  # عرض أول 15 مستخدم
                status = "🟢 نشط" if user.is_active else ("🔴 معطل" if user.disabled else "⚪ غير متصل")
                message += f"{i}. 👤 {user.name}\n"
                message += f"   📊 البروفايل: {user.profile}\n"
                message += f"   🔘 الحالة: {status}\n\n"
            
            if len(all_users) > 15:
                message += f"... و {len(all_users) - 15} مستخدمين آخرين"
        
        keyboard = [[InlineKeyboardButton("🔄 تحديث", callback_data="hotspot_all"),
                    InlineKeyboardButton("🔙 العودة", callback_data="hotspot_menu")]]
        
        await query.edit_message_text(
            message,
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
        
        self.db.log_operation(user_id, "hotspot_all", f"عرض {len(all_users)} مستخدم", True)
    
    async def show_reboot_confirmation(self, query):
        """عرض تأكيد إعادة التشغيل"""
        keyboard = [
            [
                InlineKeyboardButton("✅ نعم، أعد التشغيل", callback_data="reboot_execute"),
                InlineKeyboardButton("❌ إلغاء", callback_data="main_menu")
            ]
        ]
        
        await query.edit_message_text(
            "⚠️ تأكيد إعادة التشغيل\n\n"
            "هل أنت متأكد من رغبتك في إعادة تشغيل جهاز الميكروتك؟\n"
            "سيؤدي هذا إلى قطع جميع الاتصالات مؤقتاً.",
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
    
    async def execute_reboot(self, query):
        """تنفيذ إعادة التشغيل"""
        user_id = query.from_user.id
        client = self.get_user_connection(user_id)
        
        if not client or not client.is_connected():
            await query.edit_message_text(MESSAGES['not_logged_in'])
            return
        
        if client.reboot_system():
            await query.edit_message_text(
                "✅ تم إرسال أمر إعادة التشغيل بنجاح\n\n"
                "سيتم إعادة تشغيل الجهاز خلال ثوانٍ قليلة.\n"
                "قد تحتاج إلى تسجيل الدخول مرة أخرى بعد إعادة التشغيل."
            )
            
            # قطع الاتصال
            client.disconnect()
            self.active_connections.pop(user_id, None)
            
            self.db.log_operation(user_id, "reboot", "إعادة تشغيل الجهاز", True)
        else:
            await query.edit_message_text("❌ فشل في إعادة تشغيل الجهاز")
            self.db.log_operation(user_id, "reboot", "فشل في إعادة تشغيل الجهاز", False)
    
    async def handle_message(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """معالج الرسائل النصية"""
        user_id = update.effective_user.id
        
        if not self.is_user_authorized(user_id):
            await update.message.reply_text(MESSAGES['unauthorized'])
            return
        
        # فحص إذا كان المستخدم في انتظار بيانات تسجيل الدخول
        if context.user_data.get('waiting_for_login'):
            await self.handle_login_data(update, context)
            return
        
        # رسالة افتراضية للرسائل غير المعروفة
        await update.message.reply_text(
            "لم أفهم هذا الأمر. استخدم /start لعرض القائمة الرئيسية.",
            reply_markup=self.create_main_keyboard()
        )
    
    async def show_settings(self, query):
        """عرض الإعدادات"""
        user_id = query.from_user.id
        devices = self.db.get_user_devices(user_id)
        
        message = "⚙️ الإعدادات\n\n"
        message += f"👤 معرف المستخدم: {user_id}\n"
        message += f"🔧 عدد الأجهزة المحفوظة: {len(devices)}\n\n"
        
        if devices:
            message += "📱 الأجهزة المحفوظة:\n"
            for device in devices:
                status = "🟢 متصل" if user_id in self.active_connections else "🔴 غير متصل"
                message += f"• {device['device_name']} ({device['ip_address']}:{device['port']}) - {status}\n"
        
        keyboard = [[InlineKeyboardButton("🔙 العودة", callback_data="main_menu")]]
        
        await query.edit_message_text(
            message,
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
    
    async def show_operation_logs(self, query):
        """عرض سجل العمليات"""
        user_id = query.from_user.id
        logs = self.db.get_operation_logs(user_id, 10)
        
        if not logs:
            message = "📋 سجل العمليات\n\n❌ لا يوجد عمليات مسجلة"
        else:
            message = f"📋 سجل العمليات (آخر {len(logs)} عمليات)\n\n"
            
            for log in logs:
                status = "✅" if log['success'] else "❌"
                timestamp = log['timestamp'][:19]  # إزالة الميكروثواني
                message += f"{status} {log['operation_type']}\n"
                message += f"   📅 {timestamp}\n"
                message += f"   📝 {log['operation_details']}\n\n"
        
        keyboard = [[InlineKeyboardButton("🔙 العودة", callback_data="main_menu")]]
        
        await query.edit_message_text(
            message,
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
    
    async def discover_devices(self, query):
        """اكتشاف الأجهزة في الشبكة"""
        user_id = query.from_user.id
        client = self.get_user_connection(user_id)
        
        if not client or not client.is_connected():
            await query.edit_message_text(MESSAGES['not_logged_in'])
            return
        
        # عرض رسالة المعالجة
        await query.edit_message_text("🔍 جاري اكتشاف الأجهزة في الشبكة...")
        
        devices = client.discover_devices()
        
        if not devices:
            message = "🌐 اكتشاف الأجهزة\n\n❌ لم يتم العثور على أجهزة"
        else:
            message = f"🌐 الأجهزة المكتشفة ({len(devices)})\n\n"
            
            for i, device in enumerate(devices[:10], 1):
                message += f"{i}. 📱 {device.hostname or 'جهاز غير معروف'}\n"
                message += f"   📍 IP: {device.ip_address}\n"
                if device.mac_address:
                    message += f"   🔗 MAC: {device.mac_address}\n"
                if device.vendor:
                    message += f"   🏭 الشركة: {device.vendor}\n"
                message += "\n"
            
            if len(devices) > 10:
                message += f"... و {len(devices) - 10} أجهزة أخرى"
        
        keyboard = [[InlineKeyboardButton("🔄 إعادة المسح", callback_data="discover_devices"),
                    InlineKeyboardButton("🔙 العودة", callback_data="main_menu")]]
        
        await query.edit_message_text(
            message,
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
        
        self.db.log_operation(user_id, "discover", f"اكتشاف {len(devices)} جهاز", True)
    
    async def show_hotspot_cards_menu(self, query):
        """عرض قائمة كروت الهوتسبوت"""
        keyboard = [
            [
                InlineKeyboardButton("🎫 توليد كروت جديدة", callback_data="generate_cards"),
                InlineKeyboardButton("📋 عرض الكروت المحفوظة", callback_data="saved_cards")
            ],
            [
                InlineKeyboardButton("🔙 العودة للقائمة الرئيسية", callback_data="main_menu")
            ]
        ]
        
        await query.edit_message_text(
            "🎫 إدارة كروت الهوتسبوت\n\nاختر العملية المطلوبة:",
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
    
    async def show_troubleshoot_menu(self, query):
        """عرض قائمة تشخيص المشاكل"""
        user_id = query.from_user.id
        client = self.get_user_connection(user_id)
        
        if not client or not client.is_connected():
            await query.edit_message_text(MESSAGES['not_logged_in'])
            return
        
        # إجراء فحص سريع لصحة النظام
        await query.edit_message_text("🔍 جاري فحص صحة النظام...")
        
        health = client.get_system_health()
        
        if not health:
            await query.edit_message_text("❌ فشل في فحص صحة النظام")
            return
        
        # تحديد رمز الحالة العامة
        status_icon = {"success": "✅", "warning": "⚠️", "error": "❌"}
        overall_icon = status_icon.get(health.overall_status, "❓")
        
        message = f"🔍 تشخيص صحة النظام\n\n"
        message += f"{overall_icon} الحالة العامة: {health.overall_status.upper()}\n\n"
        
        # تفاصيل الفحص
        message += f"{status_icon.get(health.cpu_status.status, '❓')} {health.cpu_status.message}\n"
        message += f"{status_icon.get(health.memory_status.status, '❓')} {health.memory_status.message}\n"
        message += f"{status_icon.get(health.interface_status.status, '❓')} {health.interface_status.message}\n\n"
        
        # التوصيات
        if health.recommendations:
            message += "💡 التوصيات:\n"
            for rec in health.recommendations:
                message += f"• {rec}\n"
        
        keyboard = [
            [
                InlineKeyboardButton("🏓 اختبار Ping", callback_data="ping_test"),
                InlineKeyboardButton("🛤️ تتبع المسار", callback_data="traceroute_test")
            ],
            [
                InlineKeyboardButton("🔄 إعادة الفحص", callback_data="troubleshoot"),
                InlineKeyboardButton("🔙 العودة", callback_data="main_menu")
            ]
        ]
        
        await query.edit_message_text(
            message,
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
        
        self.db.log_operation(user_id, "troubleshoot", "فحص صحة النظام", True)

