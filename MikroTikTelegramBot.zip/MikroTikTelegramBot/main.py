"""
البوت الرئيسي لإدارة الميكروتك عبر تليجرام
"""

import logging
import os
from telegram.ext import Application, CommandHandler, MessageHandler, CallbackQueryHandler, filters

from config import TELEGRAM_BOT_TOKEN, ENCRYPTION_KEY
from database import DatabaseManager
from telegram_handlers import TelegramHandlers
from hotspot_manager import HotspotManager
from network_tools import NetworkTools

# إعداد نظام السجلات
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

class MikroTikTelegramBot:
    """البوت الرئيسي لإدارة الميكروتك"""
    
    def __init__(self):
        # التحقق من توكن البوت
        if not TELEGRAM_BOT_TOKEN or TELEGRAM_BOT_TOKEN == 'YOUR_BOT_TOKEN_HERE':
            raise ValueError("يرجى تعيين TELEGRAM_BOT_TOKEN في متغيرات البيئة أو ملف config.py")
        
        # تهيئة قاعدة البيانات
        self.db = DatabaseManager(encryption_key=ENCRYPTION_KEY)
        
        # تهيئة المعالجات
        self.handlers = TelegramHandlers(self.db)
        self.hotspot_manager = HotspotManager(self.db)
        self.network_tools = NetworkTools(self.db)
        
        # إنشاء التطبيق
        self.application = Application.builder().token(TELEGRAM_BOT_TOKEN).build()
        
        # تسجيل المعالجات
        self.register_handlers()
    
    def register_handlers(self):
        """تسجيل معالجات الأوامر والرسائل"""
        
        # معالجات الأوامر
        self.application.add_handler(CommandHandler("start", self.handlers.start_command))
        self.application.add_handler(CommandHandler("login", self.handlers.login_command))
        
        # معالج الاستعلامات المرجعية
        self.application.add_handler(CallbackQueryHandler(self.handle_callback_query))
        
        # معالج الرسائل النصية
        self.application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, self.handle_message))
        
        # حفظ مرجع للمعالجات في بيانات البوت
        self.application.bot_data['handlers'] = self.handlers
        self.application.bot_data['hotspot_manager'] = self.hotspot_manager
        self.application.bot_data['network_tools'] = self.network_tools
    
    async def handle_callback_query(self, update, context):
        """معالج الاستعلامات المرجعية الموحد"""
        query = update.callback_query
        data = query.data
        
        # معالجة الاستعلامات الأساسية
        if data in ["main_menu", "system_info", "hotspot_menu", "hotspot_active", 
                   "hotspot_all", "troubleshoot", "discover_devices", "reboot_confirm", 
                   "reboot_execute", "settings", "operation_logs"]:
            await self.handlers.handle_callback_query(update, context)
        
        # معالجة استعلامات الهوتسبوت
        elif data == "hotspot_cards":
            await self.hotspot_manager.show_hotspot_cards_menu(query)
        elif data == "generate_cards":
            await self.hotspot_manager.handle_generate_cards_callback(query, context)
        elif data == "saved_cards":
            await self.hotspot_manager.handle_saved_cards_callback(query)
        elif data.startswith("add_cards_to_mikrotik"):
            await self.hotspot_manager.handle_add_cards_to_mikrotik(query, context)
        elif data == "hotspot_add":
            await self.hotspot_manager.handle_hotspot_add_user(query, context)
        elif data == "hotspot_search":
            await self.hotspot_manager.handle_hotspot_search(query, context)
        
        # معالجة استعلامات أدوات الشبكة
        elif data == "ping_test":
            await self.network_tools.handle_ping_test(query, context)
        elif data == "traceroute_test":
            await self.network_tools.handle_traceroute_test(query, context)
        elif data == "advanced_diagnostics":
            await self.network_tools.handle_advanced_diagnostics(query, context)
        elif data == "interface_monitor":
            await self.network_tools.handle_interface_monitor(query, context)
        elif data == "network_speed_test":
            await self.network_tools.handle_network_speed_test(query, context)
        
        else:
            await query.answer("❌ أمر غير معروف")
    
    async def handle_message(self, update, context):
        """معالج الرسائل النصية الموحد"""
        user_data = context.user_data
        
        # فحص حالات الانتظار المختلفة
        if user_data.get('waiting_for_login'):
            await self.handlers.handle_login_data(update, context)
        elif user_data.get('waiting_for_card_params'):
            await self.hotspot_manager.handle_card_generation_params(update, context)
        elif user_data.get('waiting_for_user_data'):
            await self.hotspot_manager.handle_user_addition_data(update, context)
        elif user_data.get('waiting_for_search_query'):
            await self.hotspot_manager.handle_search_query(update, context)
        elif user_data.get('waiting_for_ping_target'):
            await self.network_tools.handle_ping_target(update, context)
        elif user_data.get('waiting_for_traceroute_target'):
            await self.network_tools.handle_traceroute_target(update, context)
        else:
            # رسالة افتراضية
            await self.handlers.handle_message(update, context)
    
    async def error_handler(self, update, context):
        """معالج الأخطاء"""
        logger.error(f"خطأ في البوت: {context.error}")
        
        if update and update.effective_user:
            user_id = update.effective_user.id
            self.db.log_operation(user_id, "error", str(context.error), False)
            
            try:
                if update.message:
                    await update.message.reply_text("❌ حدث خطأ غير متوقع. يرجى المحاولة مرة أخرى.")
                elif update.callback_query:
                    await update.callback_query.edit_message_text("❌ حدث خطأ غير متوقع. يرجى المحاولة مرة أخرى.")
            except:
                pass  # تجاهل أخطاء إرسال رسائل الخطأ
    
    def run(self):
        """تشغيل البوت"""
        logger.info("🚀 بدء تشغيل بوت إدارة الميكروتك...")
        
        # إضافة معالج الأخطاء
        self.application.add_error_handler(self.error_handler)
        
        # تشغيل البوت
        self.application.run_polling(allowed_updates=["message", "callback_query"])

def main():
    """الدالة الرئيسية"""
    try:
        bot = MikroTikTelegramBot()
        bot.run()
    except KeyboardInterrupt:
        logger.info("تم إيقاف البوت بواسطة المستخدم")
    except Exception as e:
        logger.error(f"خطأ في تشغيل البوت: {e}")
        raise

if __name__ == "__main__":
    main()

